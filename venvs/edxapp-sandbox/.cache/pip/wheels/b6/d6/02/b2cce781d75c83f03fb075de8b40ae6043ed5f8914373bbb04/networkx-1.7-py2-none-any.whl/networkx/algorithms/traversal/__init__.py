import networkx.algorithms.traversal.depth_first_search
from networkx.algorithms.traversal.depth_first_search import *
import networkx.algorithms.traversal.breadth_first_search
from networkx.algorithms.traversal.breadth_first_search import *
