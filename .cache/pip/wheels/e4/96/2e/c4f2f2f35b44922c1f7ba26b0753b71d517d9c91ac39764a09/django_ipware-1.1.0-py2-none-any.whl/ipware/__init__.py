# -*- coding: utf-8 -*-

__version__ = '1.1.0'

default_app_config = 'ipware.apps.AppConfig'
