This module provides a drop in replacement of django templates for mako templates.


