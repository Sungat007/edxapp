"""
Organizations Tests initialization module
"""
