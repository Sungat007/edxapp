from .models import sns_backend
mock_sns = sns_backend.decorator
