path.py
=======

``path.py`` implements a path objects as first-class entities, allowing
common operations on files to be invoked on those path objects directly. For
example::

    from path import Path
    d = Path('/home/guido/bin')
    for f in d.files('*.py'):
        f.chmod(0755)

``path.py`` is `hosted at Github <https://github.com/jaraco/path.py>`_.

Documentation is `hosted with PyPI <https://pythonhosted.org/path.py/>`_.

Guides and Testimonials
=======================

Yasoob has written the Python 101 `Writing a Cleanup Script
<http://freepythontips.wordpress.com/2014/01/23/python-101-writing-a-cleanup-script/>`_
based on ``path.py``.

Installing
==========

Path.py may be installed using ``setuptools``, ``distribute``, or ``pip``::

    easy_install path.py

The latest release is always updated to the `Python Package Index
<http://pypi.python.org/pypi/path.py>`_.

You may also always download the source distribution (zip/tarball), extract
it, and run ``python setup.py`` to install it.

Development
===========

To install an in-development version, use the Github links to clone or
download a snapshot of the latest code. Alternatively, if you have git
installed, you may be able to use ``pip`` or ``easy_install`` to install directly from
the repository::

    easy_install git+https://github.com/jaraco/path.py.git

Testing
=======

Tests are continuously run by Travis-CI: |BuildStatus|_

.. |BuildStatus| image:: https://secure.travis-ci.org/jaraco/path.py.png
.. _BuildStatus: http://travis-ci.org/jaraco/path.py

To run the tests, refer to the ``.travis.yml`` file for the steps run on the
Travis-CI hosts.


Changes
=======

7.2
---

 - In chmod, added support for multiple symbolic masks (separated by commas).
 - In chmod, fixed issue in setting of symbolic mask with '=' where
   unreferenced permissions were cleared.

7.1
---

 - #23: Added support for symbolic masks to ``.chmod``.

7.0
---

 - The ``open`` method now uses ``io.open`` and supports all of the
   parameters to that function. ``open`` will always raise an ``OSError``
   on failure, even on Python 2.
 - Updated ``write_text`` to support additional newline patterns.
 - The ``text`` method now always returns text (never bytes), and thus
   requires an encoding parameter be supplied if the default encoding is not
   sufficient to decode the content of the file.

6.2
---

 - ``path`` class renamed to ``Path``. The ``path`` name remains as an alias
   for compatibility.

6.1
---

 - ``chown`` now accepts names in addition to numeric IDs.

6.0
---

 - Drop support for Python 2.5. Python 2.6 or later required.
 - Installation now requires setuptools.

5.3
---

 - Allow arbitrary callables to be passed to path.walk ``errors`` parameter.
   Enables workaround for issues such as #73 and #56.

5.2
---

 - #61: path.listdir now decodes filenames from os.listdir when loading
   characters from a file. On Python 3, the behavior is unchanged. On Python
   2, the behavior will now mimick that of Python 3, attempting to decode
   all filenames and paths using the encoding indicated by
   ``sys.getfilesystemencoding()``, and escaping any undecodable characters
   using the 'surrogateescape' handler.

5.1
---

 - #53: Added ``path.in_place`` for editing files in place.

5.0
---

 - ``path.fnmatch`` now takes an optional parameter ``normcase`` and this
   parameter defaults to self.module.normcase (using case normalization most
   pertinent to the path object itself). Note that this change means that
   any paths using a custom ntpath module on non-Windows systems will have
   different fnmatch behavior. Before::

       # on Unix
       >>> p = path('Foo')
       >>> p.module = ntpath
       >>> p.fnmatch('foo')
       False

   After::

       # on any OS
       >>> p = path('Foo')
       >>> p.module = ntpath
       >>> p.fnmatch('foo')
       True

   To maintain the original behavior, either don't define the 'module' for the
   path or supply explicit normcase function::

       >>> p.fnmatch('foo', normcase=os.path.normcase)
       # result always varies based on OS, same as fnmatch.fnmatch

   For most use-cases, the default behavior should remain the same.

 - Issue #50: Methods that accept patterns (``listdir``, ``files``, ``dirs``,
   ``walk``, ``walkdirs``, ``walkfiles``, and ``fnmatch``) will now use a
   ``normcase`` attribute if it is present on the ``pattern`` parameter. The
   path module now provides a ``CaseInsensitivePattern`` wrapper for strings
   suitable for creating case-insensitive patterns for those methods.

4.4
---

 - Issue #44: _hash method would open files in text mode, producing
   invalid results on Windows. Now files are opened in binary mode, producing
   consistent results.
 - Issue #47: Documentation is dramatically improved with Intersphinx links
   to the Python os.path functions and documentation for all methods and
   properties.

4.3
---

 - Issue #32: Add ``chdir`` and ``cd`` methods.

4.2
---

 - ``open()`` now passes all positional and keyword arguments through to the
   underlying ``builtins.open`` call.

4.1
---

 - Native Python 2 and Python 3 support without using 2to3 during the build
   process.

4.0
---

 - Added a ``chunks()`` method to a allow quick iteration over pieces of a
   file at a given path.
 - Issue #28: Fix missing argument to ``samefile``.
 - Initializer no longer enforces `isinstance basestring` for the source
   object. Now any object that supplies ``__unicode__`` can be used by a
   ``path`` (except None). Clients that depend on a ValueError being raised
   for ``int`` and other non-string objects should trap these types
   internally.
 - Issue #30: ``chown`` no longer requires both uid and gid to be provided
   and will not mutate the ownership if nothing is provided.

3.2
---

 - Issue #22: ``__enter__`` now returns self.

3.1
---

 - Issue #20: `relpath` now supports a "start" parameter to match the
   signature of `os.path.relpath`.

3.0
---

 - Minimum Python version is now 2.5.

2.6
---

 - Issue #5: Implemented `path.tempdir`, which returns a path object which is
   a temporary directory and context manager for cleaning up the directory.
 - Issue #12: One can now construct path objects from a list of strings by
   simply using path.joinpath. For example::

     path.joinpath('a', 'b', 'c') # or
     path.joinpath(*path_elements)

2.5
---

 - Issue #7: Add the ability to do chaining of operations that formerly only
   returned None.
 - Issue #4: Raise a TypeError when constructed from None.


