import os


# Setup a settings module for Django
os.environ['DJANGO_SETTINGS_MODULE'] = 'tests.django_settings'
