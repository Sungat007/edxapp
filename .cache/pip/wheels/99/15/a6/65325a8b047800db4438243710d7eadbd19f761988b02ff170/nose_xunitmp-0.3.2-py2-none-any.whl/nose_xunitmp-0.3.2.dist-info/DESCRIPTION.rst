Summary
=======

Nose plugin that makes xunit xml reports work when running tests on
more than one cpu.

Installation
============

::

  $ pip install nose_xunitmp


Usage
=====

::

  $ nosetests --with-xunitmp
  $ nosetests --xunitmp-file results.xml


0.3
---

-  Updated to support nose 1.3

0.2
---

-  Fixed depedency on nose

0.1
---

-  Initial release


