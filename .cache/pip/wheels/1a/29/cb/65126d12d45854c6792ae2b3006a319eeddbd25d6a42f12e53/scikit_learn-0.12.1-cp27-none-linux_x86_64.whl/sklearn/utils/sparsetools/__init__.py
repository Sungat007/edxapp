"""sparsetools - a collection of routines for sparse matrix operations"""

from .csgraph import cs_graph_components
