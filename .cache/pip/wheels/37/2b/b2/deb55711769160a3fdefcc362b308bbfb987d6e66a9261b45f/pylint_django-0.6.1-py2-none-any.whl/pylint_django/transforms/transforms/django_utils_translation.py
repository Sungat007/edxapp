ugettext_lazy = lambda x: None
